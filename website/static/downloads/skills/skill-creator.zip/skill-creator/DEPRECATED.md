# DEPRECATED

This skill has been superseded by **skill-architect** as of 2026-01-14.

## Why Deprecated

skill-creator and skill-coach have been unified into a single authoritative meta-skill that combines:
- Systematic workflow from skill-creator
- Domain expertise encoding from skill-coach

## Migration

Use `/skill-architect` instead of this skill.

All functionality from skill-creator has been preserved and enhanced in skill-architect.

## Location

New skill: `/Users/erichowens/.claude/skills/skill-architect/`
